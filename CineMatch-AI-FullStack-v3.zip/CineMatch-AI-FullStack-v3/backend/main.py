import hashlib, hmac, secrets, sqlite3
from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr

BASE = Path(__file__).resolve().parent
DB = BASE / "cinematch.db"

app = FastAPI(title="CineMatch AI API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS sessions(
        token TEXT PRIMARY KEY,
        user_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )""")
    con.commit(); con.close()

init_db()

def hash_password(password: str):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310000)
    return salt.hex() + ":" + digest.hex()

def verify_password(password, stored):
    salt_hex, digest_hex = stored.split(":")
    check = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), 310000)
    return hmac.compare_digest(check.hex(), digest_hex)

class Signup(BaseModel):
    name: str
    email: EmailStr
    password: str

class Login(BaseModel):
    email: EmailStr
    password: str

def create_session(user_id):
    token = secrets.token_urlsafe(32)
    con = db()
    con.execute("INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)",
                (token,user_id,datetime.now(timezone.utc).isoformat()))
    con.commit(); con.close()
    return token

def user_response(row):
    return {"id":row["id"],"name":row["name"],"email":row["email"]}

@app.get("/health")
def health():
    return {"status":"ok","service":"CineMatch AI"}

@app.post("/auth/signup")
def signup(data: Signup):
    if len(data.password) < 6:
        raise HTTPException(400,"Password must be at least 6 characters.")
    con = db()
    existing = con.execute("SELECT id FROM users WHERE email=?", (data.email.lower(),)).fetchone()
    if existing:
        con.close()
        raise HTTPException(409,"An account with this email already exists.")
    cur = con.execute(
        "INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
        (data.name.strip(),data.email.lower(),hash_password(data.password),datetime.now(timezone.utc).isoformat())
    )
    con.commit()
    user_id = cur.lastrowid
    row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    con.close()
    return {"token":create_session(user_id),"user":user_response(row)}

@app.post("/auth/login")
def login(data: Login):
    con = db()
    row = con.execute("SELECT * FROM users WHERE email=?", (data.email.lower(),)).fetchone()
    con.close()
    if not row or not verify_password(data.password,row["password_hash"]):
        raise HTTPException(401,"Invalid email or password.")
    return {"token":create_session(row["id"]),"user":user_response(row)}
