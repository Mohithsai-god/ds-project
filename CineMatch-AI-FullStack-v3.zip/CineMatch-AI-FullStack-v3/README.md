# CineMatch AI — Full Stack Hackathon Edition

## What changed
- Fixed the React hooks issue that could cause the blank page after clicking Sign In.
- Landing page now stays locked until the user signs in or creates an account.
- Sign In and Create Account forms are functional.
- Backend stores users in SQLite.
- Passwords are **never stored as plaintext**; PBKDF2-HMAC-SHA256 hashes with per-user salts are stored.
- Session tokens are stored server-side and returned to the frontend.
- Movie trailers are available after authentication through a YouTube trailer modal.
- Movie cards and the hero banner can open trailers.

## Start backend

Open PowerShell in the `backend` folder:

```powershell
python -m pip install -r requirements.txt
python -m uvicorn main:app --reload --port 8000
```

Keep this terminal running.

## Start frontend

Open another PowerShell in the project root:

```powershell
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## Important
The SQLite database will be created automatically at:

```text
backend/cinematch.db
```

For a real production deployment, use PostgreSQL, HTTPS, secure HttpOnly cookies, rate limiting, email verification, password reset, and secret management. The current SQLite + token implementation is appropriate for a hackathon/demo environment.
