import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Bell, Bookmark, ChevronRight, CircleHelp, Compass, Heart, Home,
  LogIn, LogOut, Menu, Play, Search, Settings, Sparkles, Star,
  Tv, UserPlus, X, Zap
} from "lucide-react";
import "./styles.css";

const API = "http://127.0.0.1:8000";

const movies = [
  {id:1,title:"Interstellar",genre:"Sci-Fi • Drama",rating:"8.7",year:"2014",duration:"2h 49m",poster:"https://images.unsplash.com/photo-1446776877081-d282a0f896e2?auto=format&fit=crop&w=700&q=90",trailer:"zSWdZVtXT7E"},
  {id:2,title:"The Batman",genre:"Action • Crime",rating:"7.8",year:"2022",duration:"2h 56m",poster:"https://images.unsplash.com/photo-1485230405346-71acb9518d9c?auto=format&fit=crop&w=700&q=90",trailer:"mqqft2x_Aa4"},
  {id:3,title:"Dune",genre:"Sci-Fi • Epic",rating:"8.0",year:"2021",duration:"2h 35m",poster:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=700&q=90",trailer:"n9xhJrPXop4"},
  {id:4,title:"The Mandalorian",genre:"Sci-Fi • Adventure",rating:"8.6",year:"2019",duration:"3 Seasons",poster:"https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=700&q=90",trailer:"aOC8E8z_ifw"},
  {id:5,title:"House of the Dragon",genre:"Fantasy • Drama",rating:"8.3",year:"2022",duration:"2 Seasons",poster:"https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=700&q=90",trailer:"DotnJ7tTA34"},
  {id:6,title:"Dark",genre:"Mystery • Sci-Fi",rating:"8.7",year:"2017",duration:"3 Seasons",poster:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=700&q=90",trailer:"rrwycJ08PSA"},
  {id:7,title:"Breaking Bad",genre:"Crime • Drama",rating:"9.5",year:"2008",duration:"5 Seasons",poster:"https://images.unsplash.com/photo-1500673922987-e212871fec22?auto=format&fit=crop&w=700&q=90",trailer:"HhesaQXLuRY"},
  {id:8,title:"Money Heist",genre:"Crime • Thriller",rating:"8.2",year:"2017",duration:"5 Seasons",poster:"https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=700&q=90",trailer:"_InqQJRqGW4"}
];

const hero = {
  title:"The Last of Us", genre:"Thriller", year:"2023", rating:"4.7",
  description:"After a global pandemic destroys civilization, a hardened survivor must escort a teenage girl across a dangerous post-apocalyptic world.",
  image:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1600&q=90",
  trailer:"uLtkt8BonwM"
};

function Landing({openAuth}) {
  return <div className="landing">
    <header className="landing-nav">
      <div className="brand"><div className="brand-mark"><Play size={16} fill="currentColor"/></div><span>Movie<span>K</span></span></div>
      <div className="landing-links"><a href="#features">Features</a><a href="#how">How it works</a><a href="#about">About</a></div>
      <button className="signin-top" onClick={()=>openAuth("login")}>Sign In</button>
    </header>
    <section className="landing-hero">
      <div className="landing-copy">
        <div className="badge"><Sparkles size={13}/> AI-POWERED MOVIE DISCOVERY</div>
        <h1>Find movies<br/><span>you'll love.</span></h1>
        <p>CineMatch learns your taste, understands your mood, and finds your next perfect movie in seconds.</p>
        <div className="landing-actions">
          <button className="primary big" onClick={()=>openAuth("signup")}>Start Exploring <ChevronRight size={17}/></button>
          <button className="secondary big" onClick={()=>openAuth("login")}><Play size={14} fill="currentColor"/> Sign in to watch trailers</button>
        </div>
        <div className="trust"><div className="trust-avatars"><i>ST</i><i>AK</i><i>RM</i><i>+</i></div><div><b>50K+ movie lovers</b><small>discover better movies every week</small></div></div>
      </div>
      <div className="landing-visual">
        <div className="visual-glow"></div>
        <div className="stack back"><img src={movies[2].poster}/></div>
        <div className="stack main"><img src={movies[0].poster}/><div className="visual-gradient"></div><div className="visual-info"><span>AI MATCH • 98%</span><h3>Interstellar</h3><p>Because you love epic sci-fi stories</p><div><Star size={11} fill="currentColor"/> 8.7 • Sci-Fi • 2014</div></div><button className="visual-play" onClick={()=>openAuth("login")}><Play size={16} fill="currentColor"/></button></div>
        <div className="float-card match"><Sparkles size={15}/><div><b>Perfect match</b><small>Based on your taste</small></div></div>
        <div className="float-card rate"><Star size={13} fill="currentColor"/><b>4.9</b><small>user rating</small></div>
      </div>
    </section>
    <section className="features" id="features">
      <div><Sparkles/><b>AI Recommendations</b><small>Personalized picks that improve as you watch.</small></div>
      <div><Heart/><b>Made for your mood</b><small>Happy, emotional, thrilling or mind-blowing.</small></div>
      <div><Zap/><b>Discover faster</b><small>Find something great without endless scrolling.</small></div>
    </section>
    <section className="landing-bottom" id="how"><div><small>YOUR NEXT FAVORITE IS WAITING</small><h2>Stop scrolling.<br/><span>Start watching.</span></h2></div><button onClick={()=>openAuth("signup")}>Create your free account <ChevronRight size={16}/></button></section>
  </div>
}

function AuthModal({mode,setMode,onClose,onSuccess}) {
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");

  async function submit(e){
    e.preventDefault(); setLoading(true); setError("");
    try{
      const endpoint = mode==="signup" ? "/auth/signup" : "/auth/login";
      const body = mode==="signup" ? {name,email,password} : {email,password};
      const r = await fetch(API+endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
      const data = await r.json();
      if(!r.ok) throw new Error(data.detail || "Authentication failed");
      localStorage.setItem("cinematch_token",data.token);
      localStorage.setItem("cinematch_user",JSON.stringify(data.user));
      onSuccess(data.user);
    }catch(err){setError(err.message)}finally{setLoading(false)}
  }

  return <div className="auth-backdrop" onClick={onClose}>
    <div className="auth-card" onClick={e=>e.stopPropagation()}>
      <button className="close" onClick={onClose}><X/></button>
      <div className="auth-logo"><div className="brand-mark"><Play size={16} fill="currentColor"/></div></div>
      <span className="auth-kicker">{mode==="signup" ? "JOIN CINEMATCH" : "WELCOME BACK"}</span>
      <h2>{mode==="signup" ? "Create your account" : "Sign in to CineMatch"}</h2>
      <p>{mode==="signup" ? "Save your preferences and unlock personalized recommendations." : "Login is required before you can access movies and trailers."}</p>
      <form onSubmit={submit}>
        {mode==="signup" && <input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" required/>}
        <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email address" required/>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" minLength="6" required/>
        {error && <div className="auth-error">{error}</div>}
        <button className="auth-submit" disabled={loading}>{loading ? "Please wait..." : mode==="signup" ? "Create Account" : "Sign In"} <ChevronRight size={16}/></button>
      </form>
      <div className="switch-auth">{mode==="signup" ? "Already have an account?" : "New to CineMatch?"} <button onClick={()=>{setError("");setMode(mode==="signup"?"login":"signup")}}>{mode==="signup"?"Sign In":"Create account"}</button></div>
      <small className="secure-note">🔒 Passwords are securely hashed before storage.</small>
    </div>
  </div>
}

function Dashboard({user,onLogout}){
  const [search,setSearch]=useState("");
  const [watchlist,setWatchlist]=useState(new Set());
  const [selected,setSelected]=useState(null);
  const [trailer,setTrailer]=useState(null);
  const [mobile,setMobile]=useState(false);

  const filtered=useMemo(()=>{const q=search.toLowerCase().trim();return q?movies.filter(m=>(m.title+" "+m.genre+" "+m.year).toLowerCase().includes(q)):movies},[search]);
  const toggle=id=>setWatchlist(prev=>{const n=new Set(prev);n.has(id)?n.delete(id):n.add(id);return n});

  return <div className="dashboard">
    <aside className={`sidebar ${mobile?"open":""}`}>
      <div className="brand"><div className="brand-mark"><Play size={16} fill="currentColor"/></div><span>Movie<span>K</span></span></div>
      {[[Home,"Home"],[Compass,"Discover"],[Heart,"Favorites"],[Settings,"Settings"],[CircleHelp,"Help"]].map(([Icon,label])=><button className="nav-item active-if" key={label}><Icon size={17}/><span>{label}</span></button>)}
      <div className="sidebar-user"><div className="avatar">{(user.name||"U").slice(0,2).toUpperCase()}</div><div><b>{user.name}</b><small>Member</small></div></div>
      <button className="nav-item logout" onClick={onLogout}><LogOut size={17}/><span>Logout</span></button>
    </aside>
    <main className="dash-main">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMobile(!mobile)}><Menu/></button><div className="tabs"><b>Movies</b><span>TV Shows</span><span>Series</span><span>Videos</span></div><div className="top-right"><label className="search"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search movies"/></label><button className="bell"><Bell size={17}/></button><div className="avatar">{(user.name||"U").slice(0,2).toUpperCase()}</div></div></header>
      <section className="hero">
        <img src={hero.image} className="hero-bg"/><div className="hero-overlay"/>
        <div className="hero-copy"><small>HBO ORIGINAL SERIES</small><h1>{hero.title}</h1><div className="meta"><span className="score"><Star size={10} fill="currentColor"/> {hero.rating}</span><span>{hero.genre}</span><span>{hero.year}</span></div><p>{hero.description}</p><div className="actions"><button className="primary" onClick={()=>setTrailer(hero)}><Play size={15} fill="currentColor"/> Watch Trailer</button><button className="secondary" onClick={()=>toggle(999)}><Bookmark size={15}/> {watchlist.has(999)?"Saved":"Watchlist"}</button></div></div>
        <div className="episodes">{["Echoes","New World","Dead or Alive","Haunted"].map((x,i)=><div key={x}><b>{x}</b><small>Episode {i+1}</small><div className="ep-img" style={{backgroundImage:`url(${movies[(i+2)%movies.length].poster})`}}><span>{42+i*3}m</span></div></div>)}</div>
      </section>
      <section className="content-section"><div className="section-title"><h2>{search?"Search results":"Recommended for you"} <Sparkles size={15}/></h2><span>See all</span></div><div className="poster-grid">{filtered.map(m=><article className="poster" key={m.id} onClick={()=>setSelected(m)}><div><img src={m.poster}/><button onClick={e=>{e.stopPropagation();toggle(m.id)}}><Bookmark size={14} fill={watchlist.has(m.id)?"currentColor":"none"}/></button><span><Star size={9} fill="currentColor"/> {m.rating}</span></div><b>{m.title}</b><small>{m.genre}</small></article>)}</div></section>
      <section className="content-section"><div className="section-title"><h2>Trending now <Zap size={15}/></h2></div><div className="trending">{movies.slice(4,8).map((m,i)=><button key={m.id} onClick={()=>setSelected(m)}><img src={m.poster}/><strong>0{i+1}</strong><div><b>{m.title}</b><small>{m.genre}</small></div></button>)}</div></section>
    </main>
    {selected && <div className="modal-bg" onClick={()=>setSelected(null)}><div className="movie-modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}><X/></button><img src={selected.poster}/><div><span className="match">AI MATCH • 94%</span><h2>{selected.title}</h2><p>{selected.genre} • {selected.year} • {selected.duration}</p><div className="why"><Sparkles size={17}/><span><b>Why you'll like it</b><small>Matches your viewing taste and favorite genres.</small></span></div><button className="primary" onClick={()=>setTrailer(selected)}><Play size={15} fill="currentColor"/> Watch Trailer</button></div></div></div>}
    {trailer && <div className="trailer-bg" onClick={()=>setTrailer(null)}><div className="trailer-modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setTrailer(null)}><X/></button><div className="trailer-head"><div><span>TRAILER</span><h2>{trailer.title}</h2></div><button className="trailer-youtube" onClick={()=>window.open("https://www.youtube.com/watch?v="+trailer.trailer,"_blank")}>YouTube ↗</button></div><div className="video-wrap"><iframe src={`https://www.youtube.com/embed/${trailer.trailer}?autoplay=1&rel=0`} title={`${trailer.title} trailer`} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen/></div></div></div>}
  </div>
}

function App(){
  const [authOpen,setAuthOpen]=useState(false);
  const [authMode,setAuthMode]=useState("login");
  const [user,setUser]=useState(null);

  useEffect(()=>{const saved=localStorage.getItem("cinematch_user");if(saved)try{setUser(JSON.parse(saved))}catch{}},[]);

  const openAuth=(mode="login")=>{setAuthMode(mode);setAuthOpen(true)};
  const logout=()=>{localStorage.removeItem("cinematch_token");localStorage.removeItem("cinematch_user");setUser(null)};

  return <>
    {user ? <Dashboard user={user} onLogout={logout}/> : <Landing openAuth={openAuth}/>}
    {authOpen && <AuthModal mode={authMode} setMode={setAuthMode} onClose={()=>setAuthOpen(false)} onSuccess={u=>{setUser(u);setAuthOpen(false)}}/>}
  </>
}

createRoot(document.getElementById("root")).render(<App/>);
