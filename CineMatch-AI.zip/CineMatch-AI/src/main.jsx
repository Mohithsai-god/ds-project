import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Bell, Bookmark, ChevronRight, CircleHelp, Compass, Heart, Home,
  LogIn, LogOut, Menu, Play, Search, Settings, Sparkles, Star,
  Tv, UserPlus, X, Zap
} from "lucide-react";
import "./styles.css";

const API = "http://127.0.0.1:8000";

const movies = [
  {id:1,title:"Interstellar",genre:"Sci-Fi • Drama",rating:"8.7",year:"2014",duration:"2h 49m",poster:"https://cdn.ome.lt/legacy/images/galerias/Interstellar/Interstellar-Poster-18Set2014-1.jpg",description:"When a blight leaves Earth struggling to support life, former pilot Cooper joins a daring NASA mission through a wormhole near Saturn. Alongside a team of explorers, he searches distant worlds for a future for humanity—while the distance from his children makes every decision deeply personal.",director:"Christopher Nolan",cast:"Matthew McConaughey • Anne Hathaway • Jessica Chastain • Michael Caine",storyline:"A breathtaking journey across space and time, Interstellar blends large-scale science fiction with an emotional story about family, sacrifice and hope.",trailer:"zSWdZVtXT7E"},
  {id:2,title:"The Batman",genre:"Action • Crime",rating:"7.8",year:"2022",duration:"2h 56m",poster:"https://images.unsplash.com/photo-1485230405346-71acb9518d9c?auto=format&fit=crop&w=700&q=90",description:"In a crime-ridden Gotham City, a young masked vigilante investigates a series of murders and uncovers corruption reaching into the city's most powerful circles.",trailer:"mqqft2x_Aa4"},
  {id:3,title:"Dune",genre:"Sci-Fi • Epic",rating:"8.0",year:"2021",duration:"2h 35m",poster:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=700&q=90",description:"Paul Atreides travels to the dangerous desert planet Arrakis, where powerful forces compete for control of the universe’s most valuable resource.",trailer:"n9xhJrPXop4"},
  {id:4,title:"The Mandalorian",genre:"Sci-Fi • Adventure",rating:"8.6",year:"2019",duration:"3 Seasons",poster:"https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=700&q=90",description:"A lone bounty hunter journeys through the outer reaches of the galaxy, taking on dangerous missions and protecting a mysterious young companion.",trailer:"aOC8E8z_ifw"},
  {id:5,title:"House of the Dragon",genre:"Fantasy • Drama",rating:"8.3",year:"2022",duration:"2 Seasons",poster:"https://image.tmdb.org/t/p/w780/lx6hsqWXq4aVrXPjCqnMHFrGL5u.jpg",description:"Set nearly 200 years before Game of Thrones, House of the Dragon follows the Targaryen dynasty as a succession dispute divides the realm and threatens to ignite a devastating civil war. Dragons, shifting alliances and family rivalries shape the battle for the Iron Throne.",trailer:"DotnJ7tTA34"},
  {id:6,title:"Dark",genre:"Mystery • Sci-Fi",rating:"8.7",year:"2017",duration:"3 Seasons",poster:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=700&q=90",description:"When a child disappears in a small German town, four families become entangled in a mystery that spans generations and challenges their understanding of time.",trailer:"rrwycJ08PSA"},
  {id:7,title:"Breaking Bad",genre:"Crime • Drama",rating:"9.5",year:"2008",duration:"5 Seasons",poster:"https://images.unsplash.com/photo-1500673922987-e212871fec22?auto=format&fit=crop&w=700&q=90",description:"A high-school chemistry teacher facing a life-changing diagnosis turns to making illegal drugs, setting off a dangerous transformation that affects everyone around him.",trailer:"HhesaQXLuRY"},
  {id:8,title:"Money Heist",genre:"Crime • Thriller",rating:"8.2",year:"2017",duration:"5 Seasons",poster:"https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=700&q=90",description:"A carefully planned robbery brings together a group of criminals using city names as identities, while a negotiator tries to stop the operation from spiraling out of control.",trailer:"_InqQJRqGW4"}
];

const hero = {
  title:"The Last of Us", genre:"Thriller", year:"2023", rating:"4.7",
  description:"After a global pandemic destroys civilization, a hardened survivor must escort a teenage girl across a dangerous post-apocalyptic world.",
  image:"https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1600&q=90",
  trailer:"uLtkt8BonwM"
};

function Landing({openAuth}) {
  return <div className="landing">
    <header className="landing-nav">
      <div className="brand"><div className="brand-mark"><Play size={16} fill="currentColor"/></div><span>Movie<span>K</span></span></div>
      <div className="landing-links"><a href="#features">Features</a><a href="#how">How it works</a><a href="#about">About</a></div>
      <button className="signin-top" onClick={()=>openAuth("login")}>Sign In</button>
    </header>
    <section className="landing-hero">
      <div className="landing-copy">
        <div className="badge"><Sparkles size={13}/> AI-POWERED MOVIE DISCOVERY</div>
        <h1>Find movies<br/><span>you'll love.</span></h1>
        <p>CineMatch learns your taste, understands your mood, and finds your next perfect movie in seconds.</p>
        <div className="landing-actions">
          <button className="primary big" onClick={()=>openAuth("signup")}>Start Exploring <ChevronRight size={17}/></button>
          <button className="secondary big" onClick={()=>openAuth("login")}><Play size={14} fill="currentColor"/> Sign in to watch trailers</button>
        </div>
        <div className="trust"><div className="trust-avatars"><i>ST</i><i>AK</i><i>RM</i><i>+</i></div><div><b>50K+ movie lovers</b><small>discover better movies every week</small></div></div>
      </div>
      <div className="landing-visual">
        <div className="visual-glow"></div>
        <div className="stack back"><img src={movies[2].poster}/></div>
        <div className="stack main"><img src={movies[0].poster}/><div className="visual-gradient"></div><div className="visual-info"><span>AI MATCH • 98%</span><h3>Interstellar</h3><p>Because you love epic sci-fi stories</p><div><Star size={11} fill="currentColor"/> 8.7 • Sci-Fi • 2014</div></div><button className="visual-play" onClick={()=>openAuth("login")}><Play size={16} fill="currentColor"/></button></div>
        <div className="float-card match"><Sparkles size={15}/><div><b>Perfect match</b><small>Based on your taste</small></div></div>
        <div className="float-card rate"><Star size={13} fill="currentColor"/><b>4.9</b><small>user rating</small></div>
      </div>
    </section>
    <section className="features" id="features">
      <div><Sparkles/><b>AI Recommendations</b><small>Personalized picks that improve as you watch.</small></div>
      <div><Heart/><b>Made for your mood</b><small>Happy, emotional, thrilling or mind-blowing.</small></div>
      <div><Zap/><b>Discover faster</b><small>Find something great without endless scrolling.</small></div>
    </section>
    <section className="landing-bottom" id="how"><div><small>YOUR NEXT FAVORITE IS WAITING</small><h2>Stop scrolling.<br/><span>Start watching.</span></h2></div><button onClick={()=>openAuth("signup")}>Create your free account <ChevronRight size={16}/></button></section>
  </div>
}

function AuthModal({mode,setMode,onClose,onSuccess}) {
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");

  async function submit(e){
    e.preventDefault(); setLoading(true); setError("");
    try{
      const endpoint = mode==="signup" ? "/auth/signup" : "/auth/login";
      const body = mode==="signup" ? {name,email,password} : {email,password};
      const r = await fetch(API+endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
      const data = await r.json();
      if(!r.ok) throw new Error(data.detail || "Authentication failed");
      localStorage.setItem("cinematch_token",data.token);
      localStorage.setItem("cinematch_user",JSON.stringify(data.user));
      onSuccess(data.user);
    }catch(err){setError(err.message)}finally{setLoading(false)}
  }

  return <div className="auth-backdrop" onClick={onClose}>
    <div className="auth-card" onClick={e=>e.stopPropagation()}>
      <button className="close" onClick={onClose}><X/></button>
      <div className="auth-logo"><div className="brand-mark"><Play size={16} fill="currentColor"/></div></div>
      <span className="auth-kicker">{mode==="signup" ? "JOIN CINEMATCH" : "WELCOME BACK"}</span>
      <h2>{mode==="signup" ? "Create your account" : "Sign in to CineMatch"}</h2>
      <p>{mode==="signup" ? "Save your preferences and unlock personalized recommendations." : "Login is required before you can access movies and trailers."}</p>
      <form onSubmit={submit}>
        {mode==="signup" && <input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" required/>}
        <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email address" required/>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" minLength="6" required/>
        {error && <div className="auth-error">{error}</div>}
        <button className="auth-submit" disabled={loading}>{loading ? "Please wait..." : mode==="signup" ? "Create Account" : "Sign In"} <ChevronRight size={16}/></button>
      </form>
      <div className="switch-auth">{mode==="signup" ? "Already have an account?" : "New to CineMatch?"} <button onClick={()=>{setError("");setMode(mode==="signup"?"login":"signup")}}>{mode==="signup"?"Sign In":"Create account"}</button></div>
      <small className="secure-note">🔒 Passwords are securely hashed before storage.</small>
    </div>
  </div>
}

function Dashboard({user,onLogout}){
  const [search,setSearch]=useState("");
  const [watchlist,setWatchlist]=useState(()=>new Set(JSON.parse(localStorage.getItem("cinematch_watchlist")||"[]")));
  const [selected,setSelected]=useState(null);
  const [trailer,setTrailer]=useState(null);
  const [mobile,setMobile]=useState(false);
  const [page,setPage]=useState("Home");
  const [mediaTab,setMediaTab]=useState("Movies");
  const [genre,setGenre]=useState("All");
  const [displayName,setDisplayName]=useState(user.name||"");
  const [savedSettings,setSavedSettings]=useState(false);

  useEffect(()=>{localStorage.setItem("cinematch_watchlist",JSON.stringify([...watchlist]));},[watchlist]);
  const toggle=id=>setWatchlist(prev=>{const n=new Set(prev);n.has(id)?n.delete(id):n.add(id);return n});
  const navTo=label=>{setPage(label);setMobile(false);setSearch("");};
  const query=search.toLowerCase().trim();
  const mediaMovies=mediaTab==="TV Shows"?movies.filter(m=>[4,5,6,7,8].includes(m.id)):
    mediaTab==="Series"?movies.filter(m=>[4,5,6,7,8].includes(m.id)):
    mediaTab==="Videos"?movies.filter(m=>m.trailer):movies;
  const filtered=mediaMovies.filter(m=>{
    const matchesQuery=!query||(m.title+" "+m.genre+" "+m.year).toLowerCase().includes(query);
    const matchesGenre=genre==="All"||m.genre.toLowerCase().includes(genre.toLowerCase());
    return matchesQuery&&matchesGenre;
  });
  const favoriteMovies=movies.filter(m=>watchlist.has(m.id));
  const navItems=[[Home,"Home"],[Compass,"Discover"],[Heart,"Favorites"],[Settings,"Settings"],[CircleHelp,"Help"]];
  const MovieGrid=({items})=><div className="poster-grid">{items.map(m=><article className="poster" key={m.id} onClick={()=>setSelected(m)}><div><img src={m.poster} alt={`${m.title} poster`} onError={e=>{e.currentTarget.src="https://placehold.co/500x750/242342/ffffff?text=Movie+Poster"}}/><button aria-label={watchlist.has(m.id)?"Remove from favorites":"Add to favorites"} onClick={e=>{e.stopPropagation();toggle(m.id)}}><Bookmark size={14} fill={watchlist.has(m.id)?"currentColor":"none"}/></button><span><Star size={9} fill="currentColor"/> {m.rating}</span></div><b>{m.title}</b><small>{m.genre}</small></article>)}</div>;

  return <div className="dashboard">
    <aside className={`sidebar ${mobile?"open":""}`}>
      <div className="brand"><div className="brand-mark"><Play size={16} fill="currentColor"/></div><span>Movie<span>K</span></span></div>
      {navItems.map(([Icon,label])=><button className={`nav-item ${page===label?"selected": ""}`} key={label} onClick={()=>navTo(label)}><Icon size={17}/><span>{label}</span></button>)}
      <div className="sidebar-user"><div className="avatar">{(displayName||"U").slice(0,2).toUpperCase()}</div><div><b>{displayName||"Member"}</b><small>Member</small></div></div>
      <button className="nav-item logout" onClick={onLogout}><LogOut size={17}/><span>Logout</span></button>
    </aside>
    <main className="dash-main">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMobile(!mobile)}><Menu/></button><div className="tabs">{["Movies","TV Shows","Series","Videos"].map(tab=><button key={tab} className={mediaTab===tab?"tab-active":""} onClick={()=>{setMediaTab(tab);setPage("Home");setGenre("All")}}>{tab}</button>)}</div><div className="top-right"><label className="search"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search movies"/></label><button className="bell" title="Help" onClick={()=>navTo("Help")}><Bell size={17}/></button><div className="avatar">{(displayName||"U").slice(0,2).toUpperCase()}</div></div></header>

      {page==="Home"&&<>
        <section className="hero"><img src={hero.image} className="hero-bg"/><div className="hero-overlay"/><div className="hero-copy"><small>HBO ORIGINAL SERIES</small><h1>{hero.title}</h1><div className="meta"><span className="score"><Star size={10} fill="currentColor"/> {hero.rating}</span><span>{hero.genre}</span><span>{hero.year}</span></div><p>{hero.description}</p><div className="actions"><button className="primary" onClick={()=>setTrailer(hero)}><Play size={15} fill="currentColor"/> Watch Trailer</button><button className="secondary" onClick={()=>toggle(999)}><Bookmark size={15}/> {watchlist.has(999)?"Saved":"Watchlist"}</button></div></div><div className="episodes">{["Echoes","New World","Dead or Alive","Haunted"].map((x,i)=><div key={x}><b>{x}</b><small>Episode {i+1}</small><div className="ep-img" style={{backgroundImage:`url(${movies[(i+2)%movies.length].poster})`}}><span>{42+i*3}m</span></div></div>)}</div></section>
        <section className="about-project"><div><span>✧ ABOUT THE PROJECT</span><h2>Discover stories that match <em>your world.</em></h2><p>CineMatch AI is a smart movie discovery platform that helps you find films and series based on your interests. Explore curated titles, read story descriptions, save favorites and watch trailers—all in one cinematic space.</p></div><div className="about-points"><div><Sparkles/><b>Smart discovery</b><small>Explore curated movie picks.</small></div><div><Heart/><b>Your favorites</b><small>Keep the titles you love in one place.</small></div><div><Play/><b>Trailer previews</b><small>Get a glimpse before you watch.</small></div></div></section>
        <section className="content-section"><div className="section-title"><h2>{query?"Search results":`Recommended ${mediaTab.toLowerCase()}`} <Sparkles size={15}/></h2><button className="text-action" onClick={()=>navTo("Discover")}>Explore all</button></div>{filtered.length?<MovieGrid items={filtered}/>:<div className="empty-state">No titles found. Try another search.</div>}</section>
        <section className="content-section"><div className="section-title"><h2>Trending now <Zap size={15}/></h2><button className="text-action" onClick={()=>navTo("Discover")}>Discover more</button></div><div className="trending">{movies.slice(4,8).map((m,i)=><button key={m.id} onClick={()=>setSelected(m)}><img src={m.poster}/><strong>0{i+1}</strong><div><b>{m.title}</b><small>{m.genre}</small></div></button>)}</div></section>
      </>}

      {page==="Discover"&&<section className="page-panel"><div className="page-heading"><span>FIND YOUR NEXT FAVORITE</span><h1>Discover <em>something great.</em></h1><p>Browse the collection, filter by genre, or search for a title.</p></div><div className="filter-row">{["All","Sci-Fi","Drama","Action","Fantasy","Crime","Mystery","Thriller"].map(g=><button key={g} className={genre===g?"chip active-chip":"chip"} onClick={()=>setGenre(g)}>{g}</button>)}</div><div className="section-title"><h2>{genre==="All"?"Explore titles":`${genre} picks`} <Sparkles size={15}/></h2><span>{filtered.length} titles</span></div>{filtered.length?<MovieGrid items={filtered}/>:<div className="empty-state">No titles in this filter. Choose another genre.</div>}</section>}

      {page==="Favorites"&&<section className="page-panel"><div className="page-heading"><span>YOUR PERSONAL COLLECTION</span><h1>Saved <em>favorites.</em></h1><p>Your bookmarked movies and series are collected here.</p></div><div className="section-title"><h2>My watchlist <Heart size={15}/></h2><span>{favoriteMovies.length} saved</span></div>{favoriteMovies.length?<MovieGrid items={favoriteMovies}/>:<div className="empty-state"><Heart size={28}/><h3>Your favorites list is waiting</h3><p>Tap the bookmark icon on any movie to save it here.</p><button className="primary" onClick={()=>navTo("Discover")}>Discover movies <ChevronRight size={15}/></button></div>}</section>}

      {page==="Settings"&&<section className="page-panel"><div className="page-heading"><span>MAKE CINEMATCH YOURS</span><h1>Account <em>settings.</em></h1><p>Manage your profile and discovery preferences.</p></div><div className="settings-card"><div className="settings-avatar">{(displayName||"U").slice(0,2).toUpperCase()}</div><div className="settings-fields"><label>Display name<input value={displayName} onChange={e=>{setDisplayName(e.target.value);setSavedSettings(false)}} placeholder="Your name"/></label><label>Email address<input value={user.email||""} readOnly/></label><div className="settings-note">Your account email is managed by your sign-in credentials.</div><button className="primary" onClick={()=>{const updated={...user,name:displayName};localStorage.setItem("cinematch_user",JSON.stringify(updated));setSavedSettings(true)}}>Save changes</button>{savedSettings&&<span className="saved-message">Profile settings saved.</span>}</div></div><div className="settings-card preference-card"><div><h3>Discovery preferences</h3><p>Choose a starting category for your next visit.</p></div><div className="filter-row">{["Movies","TV Shows","Series","Videos"].map(t=><button key={t} className={mediaTab===t?"chip active-chip":"chip"} onClick={()=>setMediaTab(t)}>{t}</button>)}</div></div></section>}

      {page==="Help"&&<section className="page-panel"><div className="page-heading"><span>WE'RE HERE TO HELP</span><h1>Help <em>center.</em></h1><p>Quick answers to help you get the most out of CineMatch AI.</p></div><div className="help-grid">{[["How do I discover movies?","Open Discover from the sidebar, choose a genre filter, or use the search bar to find a title."],["How do I save a favorite?","Select the bookmark icon on a movie card. Your saved titles will appear under Favorites."],["How can I watch a trailer?","Open a movie card and select Watch Trailer. The trailer opens in the built-in video player."],["Where can I update my profile?","Open Settings, edit your display name and choose Save changes."],["Why can't I sign in?","Make sure the FastAPI backend is running at http://127.0.0.1:8000 and check the terminal for errors."],["What is CineMatch AI?","CineMatch AI is a movie discovery prototype with curated titles, saved favorites, descriptions and trailer previews."]].map(([q,a])=><article className="help-card" key={q}><CircleHelp/><h3>{q}</h3><p>{a}</p></article>)}</div><div className="help-contact"><b>Still need help?</b><span>Check that both the frontend and backend servers are running, then refresh the page.</span></div></section>}
    </main>
    {selected&&<div className="modal-bg" onClick={()=>setSelected(null)}><div className="movie-modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}><X/></button><img src={selected.poster} alt={`${selected.title} poster`}/><div><span className="match">AI MATCH • 94%</span><h2>{selected.title}</h2><p>{selected.genre} • {selected.year} • {selected.duration}</p><div className="movie-description"><span>THE STORY</span><p>{selected.description||"Explore this title and discover why it may be a good match for your interests."}</p>{selected.storyline&&<div className="story-note">{selected.storyline}</div>}{selected.director&&<div className="movie-credits"><div><small>DIRECTED BY</small><b>{selected.director}</b></div><div><small>STARRING</small><b>{selected.cast}</b></div></div>}</div><div className="why"><Sparkles size={17}/><span><b>Why it deserves a place on your watchlist</b><small>{selected.title==="Interstellar"?"A visually spectacular sci-fi adventure with a powerful emotional core, unforgettable music and big ideas about time and space.":"Matches your viewing taste and favorite genres. Open the trailer to get a closer look."}</small></span></div><div className="modal-actions"><button className="secondary" onClick={()=>toggle(selected.id)}><Bookmark size={15}/>{watchlist.has(selected.id)?"Remove saved":"Save favorite"}</button><button className="primary" onClick={()=>setTrailer(selected)}><Play size={15} fill="currentColor"/> Watch Trailer</button></div></div></div></div>}
    {trailer&&<div className="trailer-bg" onClick={()=>setTrailer(null)}><div className="trailer-modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setTrailer(null)}><X/></button><div className="trailer-head"><div><span>TRAILER</span><h2>{trailer.title}</h2></div><button className="trailer-youtube" onClick={()=>window.open("https://www.youtube.com/watch?v="+trailer.trailer,"_blank")}>YouTube ↗</button></div><div className="video-wrap"><iframe src={`https://www.youtube.com/embed/${trailer.trailer}?autoplay=1&rel=0`} title={`${trailer.title} trailer`} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen/></div></div></div>}
  </div>
}

function App(){
  const [authOpen,setAuthOpen]=useState(false);
  const [authMode,setAuthMode]=useState("login");
  const [user,setUser]=useState(null);

  useEffect(()=>{const saved=localStorage.getItem("cinematch_user");if(saved)try{setUser(JSON.parse(saved))}catch{}},[]);

  const openAuth=(mode="login")=>{setAuthMode(mode);setAuthOpen(true)};
  const logout=()=>{localStorage.removeItem("cinematch_token");localStorage.removeItem("cinematch_user");setUser(null)};

  return <>
    {user ? <Dashboard user={user} onLogout={logout}/> : <Landing openAuth={openAuth}/>}
    {authOpen && <AuthModal mode={authMode} setMode={setAuthMode} onClose={()=>setAuthOpen(false)} onSuccess={u=>{setUser(u);setAuthOpen(false)}}/>}
  </>
}

createRoot(document.getElementById("root")).render(<App/>);
